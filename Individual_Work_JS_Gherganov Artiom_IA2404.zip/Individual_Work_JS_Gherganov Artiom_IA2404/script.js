const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');
const historyList = document.getElementById('history-list');

let input = '';
const history = [];

// Обновление истории
function updateHistory(expression, result) {
  history.push({ expression, result });
  renderHistory();
}

// Отображение истории на странице
function renderHistory() {
  historyList.innerHTML = '';
  history.slice().reverse().forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.expression} = ${item.result}`;
    historyList.appendChild(li);
  });
}

// Очистка ввода
function clearDisplay() {
  input = '';
  display.value = '';
}

// Вычисление выражения
function calculate() {
  try {
    const result = eval(input);
    if (isFinite(result)) {
      updateHistory(input, result);
      input = result.toString();
      display.value = input;
    } else {
      display.value = 'Ошибка';
      input = '';
    }
  } catch {
    display.value = 'Ошибка';
    input = '';
  }
}

// Обработка нажатия кнопки
function handleButtonClick(value) {
  if (value === 'C') {
    clearDisplay();
  } else if (value === '=') {
    calculate();
  } else {
    input += value;
    display.value = input;
  }
}

// Назначаем события на кнопки
buttons.forEach(button => {
  button.addEventListener('click', () => {
    handleButtonClick(button.textContent);
  });
});
