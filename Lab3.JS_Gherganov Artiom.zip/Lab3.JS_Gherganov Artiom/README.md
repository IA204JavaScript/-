
# Отчет по анализу инвентаря

## Структура данных

Массив предметов, на котором будут выполняться все операции:

```javascript
const items = [
  {
    name: "Steel Sword",
    weight: 3.5,
    rarity: "rare"
  },
  {
    name: "Wooden Shield",
    weight: 5.0,
    rarity: "uncommon"
  },
  {
    name: "Healing Potion",
    weight: 0.5,
    rarity: "common"
  }
];
```

## Функции

### 1. Получение информации о предмете

```javascript
function getInfo(item) {
  return `${item.name}, ${item.weight}kg, ${item.rarity}`;
}
```

Эта функция принимает объект `item` и возвращает строку с его названием, весом и редкостью.

### 2. Изменение веса предмета

```javascript
function setWeight(item, newWeight) {
  item.weight = newWeight;
}
```

Функция позволяет изменить вес предмета, обновив его свойство `weight`.

### 3. Создание класса Item

```javascript
class Item {
  constructor(name, weight, rarity) {
    this.name = name;
    this.weight = weight;
    this.rarity = rarity;
  }

  getInfo() {
    return `${this.name}, ${this.weight}kg, ${this.rarity}`;
  }

  setWeight(newWeight) {
    this.weight = newWeight;
  }
}
```

Класс `Item` инкапсулирует данные о предмете (название, вес, редкость) и предоставляет методы для получения информации и изменения веса.

### 4. Создание класса Weapon

```javascript
class Weapon extends Item {
  constructor(name, weight, rarity, damage, durability) {
    super(name, weight, rarity);
    this.damage = damage;
    this.durability = durability;
  }

  use() {
    if (this.durability > 0) {
      this.durability -= 10;
    }
  }

  repair() {
    this.durability = 100;
  }

  getInfo() {
    return `${super.getInfo()}, ${this.damage} dmg, ${this.durability}% durability`;
  }
}
```

Класс `Weapon` наследует от `Item` и добавляет дополнительные свойства и методы для работы с оружием:
- `damage` — урон.
- `durability` — прочность оружия.
- Метод `use()` уменьшает прочность оружия.
- Метод `repair()` восстанавливает прочность оружия.

### 5. Тестирование классов

```javascript

const sword = new Item("Steel Sword", 3.5, "rare");
console.log(sword.getInfo());
sword.setWeight(4.0);
console.log(sword.getInfo());


const bow = new Weapon("Longbow", 2.0, "uncommon", 15, 100);
console.log(bow.getInfo());
bow.use();
console.log("Bow durability after use:", bow.durability);
bow.repair();
console.log("Bow durability after repair:", bow.durability);
```

Тестирование классов `Item` и `Weapon` включает создание объектов и вызов их методов. Мы проверяем:
- Изменение веса предмета.
- Работа методов `use()` и `repair()` для оружия.
- Вывод информации с помощью метода `getInfo()`.

## Заключение

В ходе выполнения данного проекта были созданы два класса: `Item` и `Weapon`. Класс `Item` представляет предметы в инвентаре, а класс `Weapon`, который расширяет `Item`, добавляет дополнительные характеристики и методы, специфичные для оружия. Программу протестировали с реальными данными, результаты были выведены в консоль.

Каждая функция и метод были протестированы и показали свою эффективность:
- Метод `getInfo()` возвращает полную информацию о предмете или оружии.
- Метод `setWeight()` корректно изменяет вес предмета.
- Класс `Weapon` успешно уменьшает прочность оружия при использовании и восстанавливает её при ремонте.


