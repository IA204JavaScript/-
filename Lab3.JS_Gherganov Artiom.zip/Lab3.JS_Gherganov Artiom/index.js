// Простой класс Item
class Item {
    constructor(name, weight, rarity) {
      this.name = name;
      this.weight = weight;
      this.rarity = rarity;
    }
  //Методы:
    getInfo() {
      return `${this.name}, ${this.weight}kg, ${this.rarity}`;
    }
  
    setWeight(newWeight) {
      this.weight = newWeight;
    }
  }
  
  // Класс Weapon, который расширяет Item
  class Weapon extends Item {
    constructor(name, weight, rarity, damage, durability) {
      super(name, weight, rarity);
      this.damage = damage;
      this.durability = durability;
    }
  
    use() {
      if (this.durability > 0) {
        this.durability -= 10;
      }
    }
  
    repair() { 
      this.durability = 100;
    }
  
    getInfo() {
      return `${super.getInfo()}, ${this.damage} dmg, ${this.durability}% durability`;
    }
  }
  
  // Примеры использования
  const sword = new Item("Steel Sword", 3.5, "rare");
  console.log(sword.getInfo());
  sword.setWeight(4.0);
  console.log(sword.getInfo());
  
  const bow = new Weapon("Longbow", 2.0, "uncommon", 15, 100);
  console.log(bow.getInfo());
  bow.use();
  console.log("Durability after use:", bow.durability);
  bow.repair();
  console.log("Durability after repair:", bow.durability);
  